#pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118 --no-cache-dir
#pip install ultralytics
#將 coco2017labels-segments.zip 解開，產生 coco 目錄
#將 train2017.zip 解開，改為 images，然後移到 coco/train 之下
#將 coco/lables/train2017移到 coco/train/之下, 並改名為 labels

#以後若有新增總類的話，需把 coco/train/label/labels.cache 及 coco/valid/label/labels.cache 刪除

import time

from ultralytics import YOLO

#將 val2017.zip 解壓至此，改名為 images，然後移到 coco/valid 之下
#將 coco/labels/val2017移到 coco/valid, 然後改名為 labels
if __name__=='__main__':
    model = YOLO("yolov8n.pt")
    print("開始訓練 .........")
    t1=time.time()
    model.train(data="./coco/data.yaml", epochs=200, imgsz=640)
    t2=time.time()
    print(f'訓練花費時間 : {t2-t1}秒')
    path=model.export()
    print(f'模型匯出路徑 : {path}')
